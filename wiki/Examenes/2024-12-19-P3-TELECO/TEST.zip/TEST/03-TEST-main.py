#!/usr/bin/env python3

import arquibot

#───────────────────────────────────────
# MAIN
#───────────────────────────────────────
#────── Ficheros
fich = {
    "main": "../main.s",  #-- Programa principal
    "deps": [
        "min_SOL.s",      
        "print_min_SOL.s"
    ]
} 

#────── Configuracion
ctx = {
    
    #-- Numero maximo de ciclos
    "MAX_STEPS": 10000,

    #-- Fichero a probar
    "TEST_FILE": fich["main"],

    #-- Modo de ejecucion: Lectura de entrada estandar o no
    "INPUT": True
}

#-- Inicializar el arquibot
salida_prog, salida_rars = arquibot.init(ctx, fich)

#-- Comprobar la salida del programa
SALIDA_ESPERADA="\nPrimer numero: Segundo numero: \n" \
                "Min(1, 2)= 1\n" \
                "\nPrimer numero: Segundo numero: \n" \
                "Min(2, 1)= 1\n" \
                "\nPrimer numero: Segundo numero: \n" \
                "Min(40, 100)= 40\n" \
                "\nPrimer numero: " \
                              
arquibot.check_output(salida_prog, SALIDA_ESPERADA)

#-- Fin!!
arquibot.end()

