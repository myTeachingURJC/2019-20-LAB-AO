import os
import requests
import sys
import ansi

RARS_NAME = "rars1_5.jar"
RARS_URL = "https://github.com/TheThirdOne/rars/releases/download/v1.5/" + RARS_NAME


#-- Check if Rars exists in the current folder
#-- Download if it does not
def download_rars():
    """
      Check if Rars exists in the current folder
      Download if it does not
    """
    #-- Comprobar si existe el RARs en el directorio actual
    if not os.path.exists(RARS_NAME):
        print("> ❌️ RARS no existe")

        #-- Descargar el ejecutable del RARs
        print("  > Descargando RARS desde la URL: " + RARS_URL)
        response = requests.get(RARS_URL)

        #-- Comprobar si ha ocurrido un error en la descarga
        if response.status_code != 200:
            ansi.line(ansi.LRED, 20)
            print(ansi.LRED + "ERROR" + ansi.DEFAULT)
            ansi.line(ansi.LRED, 20)
            print("No se ha podido realizar la descarga")
            print(f"Respuesta: {response.status_code} ({response.text})")
            print(ansi.DEFAULT)
            sys.exit(1)

        #-- Descarga realizada
        contenido = response.content
        
        # Escribir el contenido del archivo en un fichero
        with open(RARS_NAME, 'wb') as archivo:
            archivo.write(contenido)
                
        print("  > " + ansi.LGREEN + "OK!" + ansi.DEFAULT)
        print()

    print("> ✅️ RARS EXISTE")

