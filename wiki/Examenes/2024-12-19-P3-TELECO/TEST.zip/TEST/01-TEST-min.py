#!/usr/bin/env python3

import arquibot


#────── Ficheros
fich = {
    "main": "min_TB.s",  #-- Programa principal
    "deps": [
        "../min.s"
    ]
} 

#────── Configuracion
ctx = {
    
    #-- Numero maximo de ciclos
    "MAX_STEPS": 10000,

    #-- Fichero a probar
    "TEST_FILE": fich["deps"][0],

    #-- Modo de ejecucion: Lectura de entrada estandar o no
    "INPUT": False
}

#-- Inicializar el arquibot
salida_prog, salida_rars = arquibot.init(ctx, fich)

#-- Comprobar la salida del programa
SALIDA_ESPERADA="Convenio OK!!\n" \
                "OK!!\n" \
                "OK!!\n" \
                "OK!!\n" \
                              
arquibot.check_output(salida_prog, SALIDA_ESPERADA)

#-- Fin!!
arquibot.end()
