#!/usr/bin/env python3

import arquibot

#───────────────────────────────────────
# MAIN
#───────────────────────────────────────
#────── Ficheros
fich = {
    "main": "print_min_TB.s",  #-- Programa principal
    "deps": [
        "../print_min.s",
        "min_SOL.s"
    ]
} 

#────── Configuracion
ctx = {
    
    #-- Numero maximo de ciclos
    "MAX_STEPS": 10000,

    #-- Fichero a probar
    "TEST_FILE": fich["deps"][0],

    #-- Modo de ejecucion: Lectura de entrada estandar o no
    "INPUT": False
}

#-- Inicializar el arquibot
salida_prog, salida_rars = arquibot.init(ctx, fich)

#-- Comprobar la salida del programa
SALIDA_ESPERADA="\nMin(80, 100)= 80\n" \
                "Convenio OK!!\n" \
                "\nMin(1, 10)= 1\n" \
                "Convenio OK!!\n" \
                "\nMin(50, 4)= 4\n" \
                "Convenio OK!!\n" \
                "\nMin(70, 5)= 5\n" \
                "Convenio OK!!\n" 
                              
arquibot.check_output(salida_prog, SALIDA_ESPERADA)

#-- Fin!!
arquibot.end()


