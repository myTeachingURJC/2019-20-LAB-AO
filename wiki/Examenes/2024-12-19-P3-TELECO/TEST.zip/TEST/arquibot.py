import sys
import os
import re
import subprocess
import ansi
import rars

#-- Fichero donde volcar el segmento de código
TEXT="text.hex"

#-- Fichero de entrada
INPUT_FILE="input.txt"

WIDTH = 70
hay_errores = False

fich = {}

def init(ctx : dict, lfich : dict):
    global MAX_STEPS
    global TEST_FILE
    global INPUT
    global fich


    fich = lfich

    MAX_STEPS = ctx["MAX_STEPS"]
    TEST_FILE = ctx["TEST_FILE"]
    INPUT = ctx["INPUT"]

    #-- Que comience la fiesta!!
    print_header()

    #-- Fichero a probar
    print_test_file()

    #-- Make sure RARs is available
    rars.download_rars()

    #-- Comprobar si existen todos los ficheros fuentes en ensamblador
    check_files(fich)

    #-- Eliminar archivos antiguos
    cleanup()

    #-- Ejecutar el Rars!!
    salida_prog, salida_rars = run_rars()

    #-- Comprobar si hay runtime error
    check_runtime(salida_rars)

    #-- Comprobar si es un error de ensamblado
    check_assembly(salida_rars)
    
    #-- Comprobar otros errores de simulacion
    check_other_errors(salida_rars)

    #-- Leer el fichero del codigo
    get_instructions(salida_rars)

    #-- Comprobar si el programa no termina de forma controlada
    check_exit(salida_rars)

    #-- Imprimir los ciclos
    print_cycles(salida_rars)

    #-- Devolver las salidas
    return salida_prog, salida_rars


def print_header() :
    #── Imprimir encabezado
    ansi.line_doble(ansi.YELLOW, WIDTH)
    print(ansi.YELLOW + "ARQUI-BOT" + ansi.DEFAULT)
    ansi.line_doble(ansi.YELLOW, WIDTH)

    #── Volver a color normal
    print(ansi.DEFAULT, end="")


def print_test_file():
    #-- Fichero a probar
    print("TESTING: ", TEST_FILE)
    ansi.line(ansi.GREEN, WIDTH//2)

    #── Volver a color normal
    print(ansi.DEFAULT, end="")


def end():
    #-- Eliminar archivos antiguos
    cleanup()
    
    #── Imprimir final
    ansi.line(ansi.YELLOW, WIDTH)

    print(f"{ansi.WHITE}Pulsa ENTER...")
    input()

#-- Comprobar si el fichero existe
def exists(file : str) -> bool:
    if os.path.exists(file):
        print(f"> ✅️ {file} existe")
        return True
    else:  
        print(f"> ❌️ ERROR: {file} no encontrado (🔥️ERROR DE ESPECIFICACIONES)")
        print()
        sys.exit()
        


#-- Eliminar archivos antiguos
def cleanup():
    if os.path.exists(TEXT):
        os.remove(TEXT)
        print(f"> 🧹️ Eliminado {TEXT} antiguo")


#-- Comprobar si hay runtime error
def check_runtime(salida_rars : str):
    patron = r"Error in .*/([^/]+)\sline\s(\d+): Runtime exception at (0x[0-9a-fA-F]+): (.+)"
    resultado = re.search(patron, salida_rars)
    if resultado:
        print("> ❌️ ERROR en tiempo de ejecución. Ha PETADO 😱️😱️")
        archivo = resultado.group(1)
        linea = resultado.group(2)
        address = resultado.group(3)
        msg = resultado.group(4)
        print(f"🔹️Fichero: {archivo}")
        print(f"🔹️Línea: {linea}")
        print(f"🔹️Dirección: {address}")
        print(f"🔹️Error: {msg}")
        print()
        error_output_list = salida_rars.split("\n")
        print(ansi.RED + f"{error_output_list[0]}\n" + ansi.DEFAULT)
        sys.exit(1)

#-- Comprobar si es un error de ensamblado
def check_assembly(salida_rars : str):
    patron = r"Error in .*/[^/]+\sline\s(\d+).+: (.+)"
    resultado = re.search(patron, salida_rars)
    if resultado:
        print("> ❌️ ERROR: El programa NO ensambla 😱️😱️")
        linea = resultado.group(1)
        msg = resultado.group(2)
        print(f"🔹️Línea: {linea}")
        print(f"🔹️Error: {msg}")
        print()
        error_output_list = salida_rars.split("\n")
        print(ansi.RED + f"{error_output_list[0]}\n" + ansi.DEFAULT)
        sys.exit(1)

#-- Comprobar otros errores de simulacion
def check_other_errors(salida_rars : str):
    patron = r"Error in : (.+)"\
             r"\n\nSimulation terminated due to errors."
    resultado = re.search(patron, salida_rars)
    if resultado:
        print("> ❌️ ERROR: Runtime error: Error al leer instrucción 😱️😱️")
        msg = resultado.group(1)
        print(f"🔹️Error: {msg}")
        print()
        error_output_list = salida_rars.split("\n")
        print(ansi.RED + f"{error_output_list[0]}\n" + ansi.DEFAULT)
        sys.exit(1)

    
#-- Leer el fichero del codigo
def get_instructions(salida_rars : str) -> int:
    try:
        with open(TEXT, "r") as code_file:
            contenido = code_file.read()
            code = contenido.strip().split("\n")
            instrucciones = len(code)
            print(f"> 🎫 Instrucciones totales: {instrucciones}")

    except FileNotFoundError as error:
        # -- No hay codigo!
        # -- Tipicamente porque no ha puesto .text
        print(f"> ❌️ ERROR: Segmento de codigo vacio!!")


#-- Comprobar si el programa no termina de forma controlada
def check_exit(salida_rars : str):
    if "dropping off" in salida_rars:
        print(f"> ❌️ ERROR: El programa no termina llamando " \
              f"al sistema operativo")
        hay_errores = True

    ##-- Comprobar si el programa termina con normalidad, llamando a EXIT
    if "calling exit" in salida_rars:
        print(f"> ✅️ El programa termina llamando a EXIT")


#-- Imprimir los ciclos de ejecución
def print_cycles(salida_rars : str):
    
    contenido = salida_rars.strip().split("\n")

    #-- Ciclos
    ciclos = contenido[2]

    #-- Leer los ciclos
    print(f"> ⏱️  Ciclos de ejecución: {ciclos}")


def check_output(salida_prog : str, salida_esperada : str):
    #-- Comprobar salida del programa
    if salida_prog == salida_esperada:
        print(f"> ✅️ ¡Salida exacta!")
        print(ansi.GREEN + f"  Salida:\n  {salida_prog}")
        print(ansi.DEFAULT)
    else:
        hay_errores = True
        print("> ❌️ Salida NO exacta")
        print(ansi.GREEN + f"  Salida esperada: {salida_esperada}")
        print(ansi.RED + f"  Salida generada: {salida_prog}")
        print(ansi.DEFAULT)


def get_cmd_str(fich : dict, max_steps : int) -> str:
    """Devolver una cadena con el comando rars a ejecutar"""

    #-- Comando rars
    cmd_rars = f"java -jar {rars.RARS_NAME}"

    #-- Parametros para el rars
    cmd_params1 = f"nc me ic {max_steps}"
    cmd_params2 = f"dump .text HexText {TEXT}" 

    #-- Cadena con los ficheros a ensamblar
    cmd_deps = " ".join([f"{f}" for f in fich['deps']])
    cmd_fich = f"{fich['main']} {cmd_deps}" 

    #-- Generar el comando a ejecutar
    cmd_str = f"{cmd_rars} {cmd_params1} {cmd_params2} {cmd_fich}"

    #-- Devolver la cadena
    return cmd_str
    

def run_rars() -> tuple:

    #-- Generar la cadena con el comando a ejecutar
    cmd_str = get_cmd_str(fich, MAX_STEPS)

    #-- Convertirlo a lista, colocando cada argumento en un item
    #-- Necesario para ejecutar el comando con subprocess.run()
    cmd = cmd_str.split(" ")

    #-- Mostrar el comando que se ejecuta
    print("> 🚧 Ejecutando: ", end="")
    print(ansi.CYAN + cmd_str + ansi.DEFAULT)

    #-- Ejecutar el comando!
    if INPUT:
        with open(INPUT_FILE, "r") as f:
            resultado = subprocess.run(cmd, input=f.read(), 
                                       text=True, 
                                       stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE)


    else :
        resultado = subprocess.run(cmd, 
                               text=True, 
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)

    #-- Guardar la salidas estandar y de error
    #--  Salida: mensajes emitidos por el programa ensamblador
    #--  error: Mensajes emitidos por el RARs (informativos o de error)
    salida_prog = resultado.stdout
    salida_rars = resultado.stderr

    #-- Devolver las salidas
    return salida_prog, salida_rars


def check_files(fich : dict):
    
    #-- Comprobar si existe el programa principal
    exists(fich["main"])

    #-- Comprobar que los ficheros de las dependencias existen
    for f in fich["deps"]:
        exists(f)

