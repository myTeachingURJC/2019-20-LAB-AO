#!/bin/bash
clear
echo "-----Ejecutando TEST-01-----"

##-- Numero de pasos maximos
##-- Es para detectar bucles infinitos
MAX_STEPS="10000"

##-- Nombre del elemento a probar
ITEM="../conv_dec_hex.s"

##-- Nombre del fichero de constantes
SO="../serv.s"

##-- Nombre del RARs
RARS="rars1_5.jar"

##-- Fichero con el volcado de memoria de datos
MEMFILE="mem.hex"

##-- Fichero con el volcado del segmento de codigo
CODEFILE="code.hex"

##-- Fichero donde almacenar la salida del RARS
OUTPUT="output.txt"

##-- Fichero que almacena la salida de la consola
CONSOLE_OUT="console_out.txt"

##-- Fichero con las entradas del usuario
INPUT="input.txt"

##-- Valores esperados para las variables de memoria
BONUS_OK="000000ff"

##-- Borrar los ficheros temporales generados en una
##-- ejecucion previa
rm -f $MEMFILE
rm -f $OUTPUT
rm -f $CODEFILE
rm -f $CONSOLE_OUT

### Comprobar que el RARS está en directorio

if [ -f "$RARS" ]
then
  echo "> $RARS existe"
else
  echo ">> ❌️ ERROR: $RARS no está en el directorio"
  read -p "------FIN-------"
  exit 1
fi

### Comprobar si el fichero existe

if [ -f "$ITEM" ]
then
  echo "> ✅️ $ITEM existe"
else
  echo ""
  echo ">> ❌️ ERROR: $ITEM no encontrado (🔥️ERROR DE ESPECIFICACIONES)"
  read -p "------FIN-------"
  exit 1
fi

###-- Comprobar si existe el fichero de constantes del SO
if [ -f "$SO" ]
then
  echo "> ✅️ $SO existe"
else
  echo ""
  echo ">> ❌️ ERROR: $SO no encontrado (🔥️ERROR DE ESPECIFICACIONES)"
  read -p "------FIN-------"
  exit 1
fi


echo ""
echo "> ➡️  PROBANDO: "$ITEM


##--------------------------
##-- Comando a ejecutar
#---------------------------
##-- Parametros pasados al RARS:
##-- nc: No mostrar el mensaje de copyright inicial
##-- me: Mostrar los mensajes del RARs en la salida de error
##-- ic: Imprimir al final el numero de instrucciones basicas ejecutadas
##-- dump 0x10010000-0x10010010 HexText $MEMFILE: Volcar las 4 primers
##     variables a un fichero de texto, en formato texto hexadecimal
##-- 
cmd="java -jar rars1_5.jar nc me ic $MAX_STEPs dump 0x10010040-0x10010044 HexText $MEMFILE $MAX_STEPS dump .text HexText $CODEFILE $ITEM" 

##-- Mostrar comando en consola y ejecutarlo
echo $cmd
$cmd 2> $OUTPUT >$CONSOLE_OUT < $INPUT
echo ""

##-- Comprobar si ha habido errores de ensamblado o en tiempo de ejecucion
if grep -q "Runtime exception" $OUTPUT;
then
  echo "> ❌️ ERROR en tiempo de ejecución. Ha PETADO 😱️😱️"
else
  #-- Si no es de runtime comprobamos si es de ensamblado
  if grep -q "Error in" $OUTPUT; then
    echo "> ❌️ ERROR: El programa NO ensambla 😱️😱️"
    echo ""
    cat output.txt
    read -p "------FIN-------"
    exit 1
  fi
fi

##-- No hay errores, por defecto
ERRORES=0

##-- Comprobar si se ha generado el fichero con el volcado de memoria
##-- si no se ha generado es porque no se ha declaro el segmento de datos
if [ -f "$MEMFILE" ]
then
  echo "> ✅️ $MEMFILE generado"
else
  echo "> ❌️ ERROR: No hay datos en el segmento de datos (🔥️ERROR DE ESPECIFICACIONES)"
  ERRORES=1
fi

####-- Leer las variables
var1=`head -n1 $MEMFILE | tail -n1`

##-- Comprobar si el programa no termina de forma controlada
if grep -q "dropping off" $OUTPUT; then
  echo "> ❌️ ERROR: El programa no termina llamando al sistema operativo"
  ERRORES=1
fi

###-- Comprobar los mensajes de salida en la consola
if grep -q "Introduce numero en decimal:" $CONSOLE_OUT 
then
  echo "> ✅️ Consola salida: Mensaje 1"
else
  echo "> ⚠️  WARNING. Consola salida: Mensaje 1 difiere"
fi

if grep -q "Valor en hexadecimal:" $CONSOLE_OUT 
then
  echo "> ✅️ Consola salida: Mensaje 2"
else
  echo "> ⚠️  WARNING. Consola salida: Mensaje 2 difiere"
fi

###-- Comprobar si aparecen los resultados de las conversiones
if grep -q "0x0000000f" $CONSOLE_OUT
then
  echo "> ✅️ Conversion de 15 OK"
else
  echo "> ❌️ ERROR. Conversion de 15 no realizada"
  ERRORES=1
fi

if grep -q "0x000000ff" $CONSOLE_OUT
then
  echo "> ✅️ Conversion de 255 OK"
else
  echo "> ❌️ ERROR. Conversion de 255 no realizada"
  ERRORES=1
fi

##-- Comprobar si el servicio 34 se encuentra en el fichero serv.s
if grep -q "34" $SO
then
  echo "> ✅️ Servicio 34 definido"
else
  echo "> ❌️ ERROR: Servicio 34 no definido en $SO"
  ERRORES=1
fi

##-- Comprobar si termina con normalidad, llamando a exit
if grep -q "calling exit" $OUTPUT; then
  echo "> ✅️ El programa termina llamando a EXIT"
fi

##-- Leer el numero total de instrucciones
ninst=`cat $CODEFILE | wc -l`

echo "> Instrucciones totales: $ninst"

##-- Leer los ciclos
ciclos=`tail -n1 $OUTPUT`

if [ "$ciclos" = $MAX_STEPS ]
then
  echo "> ❌️ ERROR: Bucle infinito. El programa NO termina"
  ERRORES=1
fi

##-- Comprobar valor de la variable var1
if [ "$var1" = $BONUS_OK ]
then
  echo "> 😀️ 0x10010040: $var1"
  BONUS=1
else
  echo "> 😢️ (NO BONUS) 0x10010040: $var1. Debería ser: $BONUS_OK (NO BONUS)"
  BONUS=0
fi

if [ "$ERRORES" = 0 ]
then

if [ "$BONUS" = 1 ]
then

if [ "$ninst" -lt 22 ]
then
  echo "> ✅️🎖️  BONUS!!!"
fi

fi

fi

echo "> Ciclos de ejecución: $ciclos"
echo "> SALIDA EN CONSOLA"
echo ""
cat $CONSOLE_OUT
echo ""
read -p "------FIN-------"




