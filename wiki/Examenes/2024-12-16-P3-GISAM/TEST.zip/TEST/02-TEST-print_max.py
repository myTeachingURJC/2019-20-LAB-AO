#!/usr/bin/env python3

import arquibot

#───────────────────────────────────────
# MAIN
#───────────────────────────────────────
#────── Ficheros
fich = {
    "main": "print_max_TB.s",  #-- Programa principal
    "deps": [
        "../print_max.s"
    ]
} 

#────── Configuracion
ctx = {
    
    #-- Numero maximo de ciclos
    "MAX_STEPS": 10000,

    #-- Fichero a probar
    "TEST_FILE": fich["deps"][0],

    #-- Modo de ejecucion: Lectura de entrada estandar o no
    "INPUT": False
}

#-- Inicializar el arquibot
salida_prog, salida_rars = arquibot.init(ctx, fich)

#-- Comprobar la salida del programa
SALIDA_ESPERADA="\nMax(80, 100)= 100\n" \
                "Convenio OK!!\n" \
                "\nMax(1, 10)= 10\n" \
                "\nMax(50, 4)= 50\n" \
                "\nMax(70, 5)= 70\n" 
                              
arquibot.check_output(salida_prog, SALIDA_ESPERADA)

#-- Fin!!
arquibot.end()


