#!/usr/bin/env python3

import rars
import arquibot

#───────────────────────────────────────
# MAIN
#───────────────────────────────────────
#────── Ficheros
fich = {
    "main": "../main.s",  #-- Programa principal
    "deps": [
        "max_SOL.s",      
        "print_max_SOL.s"
    ]
} 

#────── Configuracion
ctx = {
    
    #-- Numero maximo de ciclos
    "MAX_STEPS": 10000,

    #-- Fichero a probar
    "TEST_FILE": fich["main"],

    #-- Modo de ejecucion: Lectura de entrada estandar o no
    "INPUT": True
}

#-- Inicializar el arquibot
salida_prog, salida_rars = arquibot.init(ctx, fich)

#-- Comprobar la salida del programa
SALIDA_ESPERADA="\nPrimer numero : Segundo numero: Valor maximo: 10\n" \
                "Max(1, 10)= 10\n" \
                "\nPrimer numero : Segundo numero: Valor maximo: 50\n" \
                "Max(50, 4)= 50\n" \
                "\nPrimer numero : " \
                              
arquibot.check_output(salida_prog, SALIDA_ESPERADA)

#-- Fin!!
arquibot.end()

